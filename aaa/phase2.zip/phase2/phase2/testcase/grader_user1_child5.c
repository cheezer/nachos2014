#include "syscall.h"
#include "usergrader1.h"
/* process to be killed */
int main(){
    assertTrueID( 1 , open( TEST_FILE_NAME0 ) > 1  );   
    int *n = -1;
    *n = 0;
    return 0;
}
