#include "stdio.h"

int main() {
	puts("hello nachos!");
	return 0;
}
