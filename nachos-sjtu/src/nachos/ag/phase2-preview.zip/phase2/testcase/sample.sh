matmult
echo 123
matmult &
matmult &
matmult &
matmult &
matmult &
exut
exit
end
